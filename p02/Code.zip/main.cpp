#include <fstream>
#include "utility.h"
#include "List.h"

using namespace std;

List<string> permuteAlphabet(int r) {
    List<string> list;

    // TODO: backtracking implementation


    return list;
}

int main(int argc, char* argv[]) {
    try {
        if (argc != 3) {
            throw CommandLineException();
        
        }
        if (!isNumber(argv[1])) {
            throw CommandLineException();
        }

        int r = string_to_int(argv[1]);
        ofstream output;
        output.open(argv[2]);

        if (output.fail()) {
            throw FileException(argv[2]);
        }

        List<string> list = permuteAlphabet(r);

        output << "The number of permutations is " << list.size() << endl;
        for (int i = 0; i < list.size(); i++) {
            string perm(r, 'a');
            list.retrieve(i, perm);
            output << perm << endl; 
        }

        output.close();

    } catch(...) {
        exit(EXIT_FAILURE);
    }

    return 0;
}