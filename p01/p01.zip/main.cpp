#include "utility.h"

#include <iostream>
#include <limits>
#include <string>

#include "Node.h"
#include "List1.h"
// #include "List2.h"

static void clear_line() {
  std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

static void print_roster(List<Personal_record>& roster) {
  // Fill in your code

}

static void lookup_by_id(const List<Personal_record>& roster) {
  // Fill in your code
  // You might need to implement and use find_by_id in utility.h

}

static void lookup_by_name_prefix(const List<Personal_record>& roster) {
  // Fill in your code
  // You might need to implement and use find_all_by_name_prefix in utility.h

}

static void menu() {
  std::cout << "\n=== Visitor Check-In & Badge Lookup ===\n"
            << "1) Import visitors from file\n"
            << "2) Print roster\n"
            << "3) Lookup by badge ID\n"
            << "4) Lookup by name (prefix)\n"
            << "5) Quit\n"
            << "Choice: ";
}

int main() {
  List<Personal_record> roster;

  while (true) {
    menu();

    int choice;
    if (!(std::cin >> choice)) {
      // EOF or invalid input
      return 0;
    }
    clear_line();

    switch (choice) {
      case 1: {
        // fill in your code to implement task 1
      }
      case 2:
        print_roster(roster);  // Implement this function
        break;
      case 3:
        lookup_by_id(roster);  // Implement this function
        break;
      case 4:
        lookup_by_name_prefix(roster);  // Implement this function
        break;
      case 5:
        return 0;
      default:
        std::cout << "Invalid choice.\n";
        break;
    }
  }
}
