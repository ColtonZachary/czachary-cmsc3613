#include "utility.h"

#include <fstream>
#include <iostream>

#include "Node.h"
#include "List1.h" // defines template List<T>
// #include "List2.h"

bool same_id(const Personal_record& a, const Personal_record& b) { // comparison helper
  return a.ID == b.ID;
}

bool same_person(const Personal_record& a, const Personal_record& b) { // comparison helper
  return a.first_name == b.first_name && a.last_name == b.last_name;
}

bool comes_before(const Personal_record& a, const Personal_record& b) {
  // Fill in your code to support sorting the records by last_name, then first_name, then ID for deterministic ordering.

}

void print_record(Personal_record& r) {
  // Fill in your code to print a Personal_record
  
}

Import_stats import_file(List<Personal_record>& roster, const std::string& filename) {
  Import_stats stats;
  // Fill in your code to support file import for Task 1 in p01

  return stats;
}

bool find_by_id(const List<Personal_record>& roster, const std::string& id, Personal_record& out) {
  // Fill in your code to support finding a record by ID for Task 3

}

int find_all_by_name_prefix(const List<Personal_record>& roster,
                            const std::string& first_prefix,
                            const std::string& last_prefix,
                            void (*visit)(Personal_record&)) {
  // Fill in your code to support finding matches by name prefix for Task 3

}
